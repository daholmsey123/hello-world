
<!DOCTYPE html>
<html>
<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<script>
var root_url = "http://comp426.cs.unc.edu:3002/api/";

$(document).ready(() => {

//build_question_interface();

  $('#login_btn').on('click', () => {

    let user = $('#login_user').val();
    let pass = $('#login_pass').val();

    console.log(user);
    console.log(pass);

    $.ajax(root_url + 'login',
      {
        type: 'GET',
        xhrFields: {withCredentials: true},
        data: {
          username: user,
          password: pass
        },
        success: (response) => {
          if (response.status) {
            build_question_interface();
            //splotch();
            //alert("hello"); // calls this thing twice
          } else {
            $('#mesg_div').html("Login failed. Try again.");
          }
        },
        error: () => {
          alert('error');
        }
      });

  });



});




var build_question_interface = function () {
  let body = $('body');

  body.empty();

  body.append('<h1>Questions and Answers</h1>');

  // var reviewbutton=$(<button>).


  let qlist = $('<div></div>');

  body.append(qlist);

  $.ajax(root_url + "questions",
    {
      type: 'GET',
      dataType: 'json',
      xhrFields: {withCredentials: true},
      success: (response) => {
        let qarray = response.data;
        for (let i=0; i<qarray.length; i++) {
          let qdiv = create_question_div(qarray[i]);
          qlist.append(qdiv);
          let qid = qarray[i].id
          $.ajax(root_url + 'answers/' + qid,
            {
              type: 'GET',
              dataType: 'json',
              xhrFields: {withCredentials: true},
              success: (response) => {
                if (response.data != null) {
                  console.log("hat");

                  let answer = response.data;
                  qdiv.append('<div class="answer" id="aid_' + answer.answer_id + '">' +
                    answer.answer_text + '</div>');
                  qdiv.addClass('answered');


                  var delbutton=$('<button>').text("delete").on('click',()=>{
                    alert("clicked on button");
                    alert(qid);

                    $.ajax(root_url+'answers/'+qid,
                      {
                        type:'DELETE',
                        datatype:'json',
                        xhrFields: {withCredentials:true},
                        success:(response) =>{
                          alert("You have deleted this answer");
                          qdiv.removeClass('answered');
                          delbutton.remove();
                          qdiv.append('<textarea id="textareanum'+qid+'" placeholder="type your answer here">'+'</textarea>');
                          //("#aid"+answer.answer_id).remove();
                          //qdiv.removeClass('answered');

                        },
                        error:()=>{alert("nope")}

                      })
                  })
                  qdiv.append(delbutton) ;
                  alert("hi");
                  console.log(answer.id);//makeanswered(qdiv, qid);
                }

                else{

                  qdiv.append('<textarea id="textareanum'+qid+'" placeholder="type your answer here">'+'</textarea>');
                  var subemptybutton=$('<button>').text("submit").on('click',()=>
                    {
                      let g=$( "#textareanum"+qid).val();
                      alert(g);
                      let p=root_url+'answers/'+qid+'?answer='+encodeURIComponent(g);
                      $.ajax(p,
                        {
                          type:'PUT',
                          datatype:'json',
                          xhrFields: {withcredentials:true},

                          success:(response)=>{
                            alert("that shite is dank");
                            $("#textareanum"+qid).remove();
                            subemptybutton.remove();
                            qdiv.append('<div class="answer" id="aid_' + qid + '">' +
                              g + '</div>');
                            alert("finished")
                          }
                        }

                      )}

                  )

                  qdiv.append(subemptybutton);

                }

              }

            }
          )}


      }
    })


  /*   var groz = function(qdiv,qid) {
    alert(" you have entered groz");
    $.ajax(root_url+'answers/'+qid,
    {
    type:'Delete',
    datatype:'json',
    xhrFields: {withCredentials:true},
    success:(response) =>{
    alert("You have deleted this answer");
    },
    error:()=>{alert("nope")}

    });

    }


    function makeanswered(qdiv, qid){
                              qdiv.append('<button id="deletebutton'+ qid+'">'+ "delete your answer"+'</button>');
             $('#deletebutton'+qid).on('click',groz(qdiv,qid));

   }
         */



  let create_question_div = (question) => {
    let qdiv = $('<div class="question" id="qid_' + question.id + '"></div>');
    qdiv.append('<div class="qtitle">' + question.title + '</div>');
    qdiv.append('<div class="count">' + question.answerCount + '</div>');
    return qdiv;
  }



};

</script>
</head>
<body>
<h1>A4 API Example</h1>

<div id="login_div">
  User: <input type="text" id="login_user"><br>
  Password: <input type="text" id="login_pass"><br>
  <button id="login_btn">Login</button>
</div>
<div id="mesg_div"></div>



</body>

</html>
